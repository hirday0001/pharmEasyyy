<?php
$firstn=$_GET["firstname"];
$lastn=$_GET["lastname"];
$sub=$_GET["subject"];
$con=mysqli_connect("localhost","root","","test1");
$sql="Insert into cont (firstn,lastn,sub) values ('$firstn','$lastn','$sub')";
if (mysqli_query($con,$sql))
{
	echo "Thank You For Your Response,We Will Look Into It ASAP!";
	header("refresh:5","")
}
else
{
	echo "Something Went Wrong";
}
mysqli_close($con);
?>